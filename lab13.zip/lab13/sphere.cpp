#include "sphere.h"

sphere::sphere()
{
	area = 0;
	redius = 0;

}

sphere::sphere(float a, float red)
{
	area = a;
	redius = red;
}

void sphere::setRedius(float)
{
}

float sphere::getRadius()
{
	return 0.0f;
}






sphere::~sphere()
{
}
